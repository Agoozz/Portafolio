const form = document.getElementById('agendaForm');
const tablaBody = document.getElementById('agendaTableBody');
const contador = document.getElementById('contadorClases');
const modalClase = document.getElementById('modalClase');
const modalInstancia = bootstrap.Modal.getOrCreateInstance(modalClase);
const submitBtn = document.getElementById('guardarClaseBtn');
const alumnoSelect = document.getElementById('alumnoClase');
const fechaInput = document.getElementById('fechaClase');
const horaInput = document.getElementById('horaClase');
const busquedaAlumno = document.getElementById('busquedaAlumno');
const filtroEstadoClase = document.getElementById('filtroEstadoClase');

let clases = [];
let alumnos = [];
let materias = [];
let claseEditandoId = null;
let alertedVencidas = false;

async function cargarMaterias() {
  try {
    const response = await fetch('/api/materias');
    if (response.ok) {
      materias = await response.json();
    }
  } catch (error) {
    console.error('No se pudieron leer las materias del servidor', error);
  }
}

function actualizarSelectMaterias() {
  const selectMateria = document.getElementById('materiaClase');
  const seleccionActual = selectMateria.value;

  selectMateria.innerHTML = '<option value="">Seleccioná una materia</option>' + materias.map((materia) => `
    <option value="${materia}" ${materia === seleccionActual ? 'selected' : ''}>
      ${materia}
    </option>
  `).join('');
}

async function cargarClases() {
  try {
    const response = await fetch('/api/agenda');
    if (response.ok) {
      const guardados = await response.json();
      clases = guardados.sort((a, b) => new Date(`${a.fecha}T${a.hora}`) - new Date(`${b.fecha}T${b.hora}`));
    }
  } catch (error) {
    console.error('No se pudieron leer las clases del servidor', error);
  }
}

async function cargarAlumnos() {
  try {
    const response = await fetch('/api/alumnos');
    if (response.ok) {
      alumnos = await response.json();
    }
  } catch (error) {
    console.error('No se pudieron leer los alumnos del servidor', error);
  }
}

function cargarAlumnosEnSelect() {
  const seleccionActual = alumnoSelect.value;

  alumnoSelect.innerHTML = '<option value="">Seleccioná un alumno</option>' + alumnos.map((alumno) => `
    <option value="${alumno.nombre} ${alumno.apellido}" ${`${alumno.nombre} ${alumno.apellido}` === seleccionActual ? 'selected' : ''}>
      ${alumno.nombre} ${alumno.apellido}
    </option>
  `).join('');

  if (alumnos.length === 0) {
    alumnoSelect.innerHTML = '<option value="">No hay alumnos cargados</option>';
  }
}

function formatearFecha(fecha) {
  return new Date(`${fecha}T00:00:00`).toLocaleDateString('es-AR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
}

function renderTabla() {
  const termino = busquedaAlumno.value.trim().toLowerCase();
  const estadoFiltro = filtroEstadoClase.value;

  const filtradas = clases.filter((clase) => {
    const nombreAlumno = (clase.alumno || '').toLowerCase();
    const cumpleBusqueda = !termino || nombreAlumno.includes(termino);
    const cumpleEstado = !estadoFiltro || clase.estado === estadoFiltro;
    return cumpleBusqueda && cumpleEstado;
  });

  contador.textContent = `${filtradas.length} clase${filtradas.length === 1 ? '' : 's'}`;

  if (!filtradas.length) {
    tablaBody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center text-muted py-4">No hay clases programadas que coincidan con los filtros.</td>
      </tr>
    `;
    return;
  }

  tablaBody.innerHTML = filtradas.map((clase) => `
    <tr>
      <td>${formatearFecha(clase.fecha)}</td>
      <td>${clase.hora}</td>
      <td>${clase.alumno}</td>
      <td>${clase.materia}</td>
      <td><span class="badge ${clase.estado === 'Completada' ? 'bg-success-subtle text-success' : clase.estado === 'Cancelada' ? 'bg-danger-subtle text-danger' : 'bg-primary-subtle text-primary'}">${clase.estado}</span></td>
      <td>
        <div class="d-flex gap-2">
          <button type="button" class="btn btn-sm btn-outline-primary" data-action="editar" data-id="${clase.id}">Editar</button>
          <button type="button" class="btn btn-sm btn-outline-danger" data-action="eliminar" data-id="${clase.id}">Eliminar</button>
        </div>
      </td>
    </tr>
  `).join('');
}

function aplicarRestriccionesAgenda() {
  const hoy = new Date();
  const hoyISO = hoy.toISOString().split('T')[0];

  if (claseEditandoId) {
    fechaInput.removeAttribute('min');
  } else {
    fechaInput.setAttribute('min', hoyISO);
    fechaInput.min = hoyISO;
    if (!fechaInput.value) {
      fechaInput.value = hoyISO;
    }
  }

  horaInput.setAttribute('min', '06:00');
  horaInput.min = '06:00';
  horaInput.setAttribute('max', '23:59');
  horaInput.max = '23:59';
}

function limpiarFormulario() {
  form.reset();
  document.getElementById('claseId').value = '';
  claseEditandoId = null;
  aplicarRestriccionesAgenda();
  cargarAlumnosEnSelect();
  actualizarSelectMaterias();
  if (submitBtn) {
    submitBtn.textContent = 'Guardar clase';
  }
}

function cargarClaseEnFormulario(clase) {
  claseEditandoId = clase.id;
  document.getElementById('claseId').value = clase.id;
  document.getElementById('fechaClase').value = clase.fecha;
  document.getElementById('horaClase').value = clase.hora;
  actualizarSelectMaterias();
  document.getElementById('materiaClase').value = clase.materia;
  document.getElementById('estadoClase').value = clase.estado;
  document.getElementById('observacionesClase').value = clase.observaciones || '';
  cargarAlumnosEnSelect();
  alumnoSelect.value = clase.alumno;
  aplicarRestriccionesAgenda();
  if (submitBtn) {
    submitBtn.textContent = 'Actualizar clase';
  }
}

function verificarClasesVencidas() {
  if (alertedVencidas) return;
  const ahora = new Date();
  const tieneVencidas = clases.some(clase => {
    if (clase.estado !== 'Programada') return false;
    const fechaHora = new Date(`${clase.fecha}T${clase.hora || '00:00'}:00`);
    return fechaHora < ahora;
  });

  if (tieneVencidas) {
    alertedVencidas = true;
    alert("Recordá actualizar la información de la agenda");
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const alumno = alumnoSelect.value.trim();
  const materia = document.getElementById('materiaClase').value;
  const fecha = document.getElementById('fechaClase').value;
  const hora = document.getElementById('horaClase').value;
  const estado = document.getElementById('estadoClase').value;

  if (!alumno) {
    alert('Seleccioná un alumno para la clase');
    return;
  }

  if (!fecha || !hora) {
    alert('Completá la fecha y la hora de la clase');
    return;
  }

  if (!claseEditandoId) {
    const fechaSeleccionada = new Date(`${fecha}T00:00:00`);
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);

    if (fechaSeleccionada < hoy) {
      alert('No se puede agendar una clase en una fecha anterior a hoy');
      return;
    }

    const horaNumero = Number(hora.split(':')[0]);
    if (horaNumero >= 0 && horaNumero < 6) {
      alert('Las clases deben agendarse a partir de las 06:00 AM');
      return;
    }

    const fechaHoraSeleccionada = new Date(`${fecha}T${hora}:00`);
    if (fechaHoraSeleccionada < new Date()) {
      alert('No se puede agendar una clase en una hora anterior a la actual');
      return;
    }
  }

  const clase = {
    id: claseEditandoId || Date.now(),
    alumno,
    materia,
    fecha,
    hora,
    estado,
    observaciones: document.getElementById('observacionesClase').value.trim()
  };

  try {
    let response;
    if (claseEditandoId) {
      response = await fetch(`/api/agenda/${claseEditandoId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(clase)
      });
    } else {
      response = await fetch('/api/agenda', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(clase)
      });
    }

    if (response.ok) {
      window.dispatchEvent(new StorageEvent('storage', {
        key: 'agendaProfe_agenda'
      }));
      await cargarClases();
      renderTabla();
      limpiarFormulario();
      modalInstancia.hide();
    }
  } catch (error) {
    console.error('Error al guardar la clase', error);
  }
});

const cancelarEdicionBtn = document.getElementById('cancelarClase');
cancelarEdicionBtn.addEventListener('click', () => {
  limpiarFormulario();
  modalInstancia.hide();
});

modalClase.addEventListener('hidden.bs.modal', () => {
  limpiarFormulario();
});

tablaBody.addEventListener('click', async (event) => {
  const boton = event.target.closest('[data-action]');
  if (!boton) return;

  const claseId = Number(boton.dataset.id);
  const clase = clases.find((item) => item.id === claseId);
  if (!clase) return;

  if (boton.dataset.action === 'editar') {
    cargarClaseEnFormulario(clase);
    modalInstancia.show();
  }

  if (boton.dataset.action === 'eliminar') {
    if (confirm("¿Estás seguro de que querés eliminar esta clase?")) {
      try {
        const response = await fetch(`/api/agenda/${claseId}`, {
          method: 'DELETE'
        });
        if (response.ok) {
          window.dispatchEvent(new StorageEvent('storage', {
            key: 'agendaProfe_agenda'
          }));
          await cargarClases();
          renderTabla();
          if (claseEditandoId === claseId) {
            limpiarFormulario();
          }
        }
      } catch (error) {
        console.error('Error al eliminar la clase', error);
      }
    }
  }
});

document.getElementById('btnNuevaClase').addEventListener('click', () => {
  limpiarFormulario();
  modalInstancia.show();
});

modalClase.addEventListener('shown.bs.modal', () => {
  aplicarRestriccionesAgenda();
});

window.addEventListener('storage', async (event) => {
  if (event.key === 'agendaProfe_alumnos') {
    await cargarAlumnos();
    cargarAlumnosEnSelect();
  }
  if (event.key === 'agendaProfe_materias') {
    await cargarMaterias();
    actualizarSelectMaterias();
    renderTabla();
  }
  if (event.key === 'agendaProfe_agenda') {
    await cargarClases();
    renderTabla();
  }
});

[busquedaAlumno, filtroEstadoClase].forEach((elemento) => {
  elemento.addEventListener('input', renderTabla);
  elemento.addEventListener('change', renderTabla);
});

async function init() {
  await cargarMaterias();
  await cargarAlumnos();
  await cargarClases();
  renderTabla();
  limpiarFormulario();
  verificarClasesVencidas();
}

init();

