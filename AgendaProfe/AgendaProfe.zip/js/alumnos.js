const STORAGE_KEY = 'agendaProfe_alumnos';
const PACKS_STORAGE_KEY = 'agendaProfe_packs';
const MATERIAS_STORAGE_KEY = 'agendaProfe_materias';

const form = document.getElementById('alumnoForm');
const tablaBody = document.getElementById('alumnoTableBody');
const contador = document.getElementById('contadorAlumnos');
const busqueda = document.getElementById('busqueda');
const filtroMateria = document.getElementById('filtroMateria');
const filtroServicio = document.getElementById('filtroServicio');
const filtroEstado = document.getElementById('filtroEstado');
const cancelarEdicionBtn = document.getElementById('cancelarEdicion');
const modalAlumno = document.getElementById('modalAlumno');
const paqueteClases = document.getElementById('paqueteClases');
const campoPaquete = document.getElementById('campoPaquete');
const submitBtn = document.getElementById('guardarAlumnoBtn');
const campoClasesRestantes = document.getElementById('campoClasesRestantes');
const clasesRestantesInput = document.getElementById('clasesRestantes');

let alumnos = [];
let alumnoEditandoId = null;
const modalInstancia = bootstrap.Modal.getOrCreateInstance(modalAlumno);

async function cargarAlumnos() {
  try {
    const response = await fetch('/api/alumnos');
    if (response.ok) {
      alumnos = await response.json();
    }
  } catch (error) {
    console.error('Error al cargar alumnos desde el servidor', error);
  }
}

async function obtenerMaterias() {
  try {
    const response = await fetch('/api/materias');
    if (response.ok) {
      return await response.json();
    }
  } catch (error) {
    console.error('No se pudieron leer las materias del servidor', error);
  }
  return [];
}

async function actualizarCamposMaterias() {
  const listaMaterias = await obtenerMaterias();
  
  const seleccionFiltroActual = filtroMateria.value;
  filtroMateria.innerHTML = '<option value="">Todas</option>' + listaMaterias.map(materia => `
    <option value="${materia}" ${materia === seleccionFiltroActual ? 'selected' : ''}>${materia}</option>
  `).join('');

  const materiasDiv = document.getElementById('materias');
  const checkboxesSeleccionados = Array.from(materiasDiv.querySelectorAll('input[type="checkbox"]:checked'))
    .map(cb => cb.value);

  materiasDiv.innerHTML = listaMaterias.map((materia, index) => `
    <div class="form-check mb-2">
      <input class="form-check-input" type="checkbox" value="${materia}" id="materia_${index}" ${checkboxesSeleccionados.includes(materia) ? 'checked' : ''}>
      <label class="form-check-label" for="materia_${index}">${materia}</label>
    </div>
  `).join('');
}

function toBadge(servicio, paquete) {
  const mapa = {
    paquete: 'bg-success-subtle text-success',
    clase: 'bg-primary-subtle text-primary',
    debe: 'bg-danger-subtle text-danger'
  };

  const etiqueta = {
    paquete: paquete ? `Paga paquete (${paquete})` : 'Paga paquete',
    clase: 'Paga por clase',
    debe: 'Debe'
  };

  return `<span class="badge ${mapa[servicio] || 'bg-secondary-subtle text-secondary'}">${etiqueta[servicio] || servicio}</span>`;
}

async function obtenerPacksDisponibles() {
  try {
    const response = await fetch('/api/packs');
    if (response.ok) {
      return await response.json();
    }
  } catch (error) {
    console.error('No se pudieron leer los packs disponibles', error);
  }
  return [];
}

async function actualizarListaPaquetes() {
  const packs = await obtenerPacksDisponibles();
  const seleccionActual = paqueteClases.value;

  paqueteClases.innerHTML = '<option value="">Seleccioná un pack</option>' + packs.map((pack) => `
    <option value="${pack.nombre}" ${pack.nombre === seleccionActual ? 'selected' : ''}>
      ${pack.nombre} — ${pack.clases} clases
    </option>
  `).join('');

  if (packs.length > 0 && !seleccionActual) {
    paqueteClases.value = packs[0].nombre;
  }

  paqueteClases.disabled = packs.length === 0;
  if (packs.length === 0) {
    paqueteClases.innerHTML = '<option value="">No hay packs disponibles</option>';
  }
}

function renderTabla() {
  const termino = busqueda.value.trim().toLowerCase();
  const materiaFiltro = filtroMateria.value;
  const servicioFiltro = filtroServicio.value;
  const estadoFiltro = filtroEstado.value;

  const filtrados = alumnos.filter((alumno) => {
    const nombreCompleto = `${alumno.nombre} ${alumno.apellido}`.toLowerCase();
    const cumpleBusqueda = !termino || nombreCompleto.includes(termino);
    const cumpleMateria = !materiaFiltro || alumno.materias.includes(materiaFiltro);
    const cumpleServicio = !servicioFiltro || alumno.servicio === servicioFiltro;
    const cumpleEstado = !estadoFiltro || alumno.estado === estadoFiltro;

    return cumpleBusqueda && cumpleMateria && cumpleServicio && cumpleEstado;
  });

  contador.textContent = `${filtrados.length} alumno${filtrados.length === 1 ? '' : 's'}`;

  if (!filtrados.length) {
    tablaBody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center text-muted py-4">No se encontraron alumnos con esos filtros.</td>
      </tr>
    `;
    return;
  }

  tablaBody.innerHTML = filtrados.map((alumno) => `
    <tr>
      <td>
        <div class="fw-semibold">${alumno.nombre} ${alumno.apellido}</div>
        <div class="small text-muted">${alumno.observaciones || 'Sin observaciones'}</div>
      </td>
      <td>
        ${toBadge(alumno.servicio, alumno.paquete)}
        ${alumno.servicio === 'paquete' ? `<div class="small text-muted mt-1">Saldo: <strong class="${(alumno.clasesRestantes || 0) === 0 ? 'text-danger' : 'text-success'}">${alumno.clasesRestantes || 0}</strong> cl.</div>` : ''}
      </td>
      <td>
        <div class="d-flex flex-wrap gap-1">
          ${alumno.materias.map((materia) => `<span class="badge bg-light text-dark border">${materia}</span>`).join('')}
        </div>
      </td>
      <td><span class="badge bg-secondary-subtle text-secondary">${alumno.estado}</span></td>
      <td>
        <div>${alumno.telefono || 'Sin teléfono'}</div>
        <div class="small text-muted">${alumno.email || 'Sin email'}</div>
      </td>
      <td>
        <div class="d-flex gap-2">
          <button class="btn btn-sm btn-outline-primary" data-action="editar" data-id="${alumno.id}">Editar</button>
          <button class="btn btn-sm btn-outline-danger" data-action="eliminar" data-id="${alumno.id}">Eliminar</button>
        </div>
      </td>
    </tr>
  `).join('');
}

async function actualizarPaquete() {
  const servicio = document.getElementById('servicio').value;

  if (servicio === 'paquete') {
    await actualizarListaPaquetes();
    campoPaquete.classList.remove('d-none');
    campoClasesRestantes.classList.remove('d-none');
  } else {
    campoPaquete.classList.add('d-none');
    campoClasesRestantes.classList.add('d-none');
    paqueteClases.value = '';
    clasesRestantesInput.value = 0;
  }
}

async function limpiarFormulario() {
  form.reset();
  await actualizarCamposMaterias();
  await actualizarListaPaquetes();
  document.getElementById('alumnoId').value = '';
  document.getElementById('deuda').value = 0;
  clasesRestantesInput.value = 0;
  document.querySelectorAll('#materias input[type="checkbox"]').forEach((checkbox) => {
    checkbox.checked = false;
  });
  await actualizarPaquete();
  document.getElementById('estado').value = 'Activo';
  alumnoEditandoId = null;
  cancelarEdicionBtn.classList.add('d-none');
  if (submitBtn) {
    submitBtn.textContent = 'Guardar alumno';
  }
}

async function cargarAlumnoEnFormulario(alumno) {
  await actualizarCamposMaterias();
  await actualizarListaPaquetes();
  document.getElementById('alumnoId').value = alumno.id;
  document.getElementById('nombre').value = alumno.nombre;
  document.getElementById('apellido').value = alumno.apellido;
  document.getElementById('telefono').value = alumno.telefono || '';
  document.getElementById('email').value = alumno.email || '';
  document.getElementById('servicio').value = alumno.servicio;
  document.getElementById('deuda').value = alumno.deuda || 0;
  clasesRestantesInput.value = alumno.clasesRestantes || 0;
  document.getElementById('estado').value = alumno.estado;
  document.getElementById('observaciones').value = alumno.observaciones || '';
  paqueteClases.value = alumno.paquete || '';

  document.querySelectorAll('#materias input[type="checkbox"]').forEach((checkbox) => {
    checkbox.checked = alumno.materias.includes(checkbox.value);
  });

  await actualizarPaquete();
  cancelarEdicionBtn.classList.remove('d-none');
  if (submitBtn) {
    submitBtn.textContent = 'Actualizar alumno';
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const materiasSeleccionadas = Array.from(document.querySelectorAll('#materias input[type="checkbox"]'))
      .filter((checkbox) => checkbox.checked)
      .map((checkbox) => checkbox.value);

    const servicio = document.getElementById('servicio').value;
    const paqueteSeleccionado = servicio === 'paquete' ? paqueteClases.value : '';

    if (servicio === 'paquete' && !paqueteSeleccionado) {
      alert('Seleccioná un pack para el alumno');
      return;
    }

    const alumno = {
      id: alumnoEditandoId || Date.now(),
      nombre: document.getElementById('nombre').value.trim(),
      apellido: document.getElementById('apellido').value.trim(),
      telefono: document.getElementById('telefono').value.trim(),
      email: document.getElementById('email').value.trim(),
      servicio,
      paquete: paqueteSeleccionado,
      clasesRestantes: servicio === 'paquete' ? Number(clasesRestantesInput.value || 0) : 0,
      deuda: Number(document.getElementById('deuda').value || 0),
      materias: materiasSeleccionadas,
      estado: document.getElementById('estado').value,
      observaciones: document.getElementById('observaciones').value.trim(),
      fechaAlta: new Date().toISOString()
    };

    let response;
    if (alumnoEditandoId) {
      response = await fetch(`/api/alumnos/${alumnoEditandoId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(alumno)
      });
    } else {
      response = await fetch('/api/alumnos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(alumno)
      });

      // Registrar pago automático inicial
      if (servicio === 'paquete' && paqueteSeleccionado) {
        const packs = await obtenerPacksDisponibles();
        const pack = packs.find(p => p.nombre === paqueteSeleccionado);
        if (pack) {
          const precioPack = Number(pack.precio || 0);
          const deudaIngresada = Number(document.getElementById('deuda').value || 0);
          const montoPago = precioPack - deudaIngresada;

          if (montoPago > 0) {
            const pagoInicial = {
              id: Date.now(),
              alumnoId: alumno.id,
              alumnoNombre: `${alumno.nombre} ${alumno.apellido}`,
              monto: montoPago,
              fecha: new Date().toISOString().split('T')[0],
              hora: new Date().toTimeString().slice(0, 5),
              metodo: 'Efectivo',
              observaciones: `Pago inicial de pack al registrar alumno (${paqueteSeleccionado})`
            };

            await fetch('/api/pagos', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(pagoInicial)
            });
          }
        }
      }
    }

    if (response.ok) {
      window.dispatchEvent(new StorageEvent('storage', {
        key: STORAGE_KEY
      }));

      await cargarAlumnos();
      renderTabla();
      await limpiarFormulario();
    }
  } catch (e) {
    console.error("Error al guardar alumno", e);
  } finally {
    setTimeout(() => {
      modalInstancia.hide();
    }, 0);
  }
});

cancelarEdicionBtn.addEventListener('click', async () => {
  await limpiarFormulario();
  modalInstancia.hide();
});

tablaBody.addEventListener('click', async (event) => {
  const action = event.target.dataset.action;

  if (!action) return;

  const alumnoId = Number(event.target.dataset.id);

  if (action === 'editar') {
    const alumno = alumnos.find((item) => item.id === alumnoId);
    if (alumno) {
      alumnoEditandoId = alumno.id;
      await cargarAlumnoEnFormulario(alumno);
      modalInstancia.show();
    }
  }

  if (action === 'eliminar') {
    if (confirm("¿Estás seguro de que querés eliminar este alumno?")) {
      try {
        const response = await fetch(`/api/alumnos/${alumnoId}`, {
          method: 'DELETE'
        });
        if (response.ok) {
          window.dispatchEvent(new StorageEvent('storage', {
            key: STORAGE_KEY
          }));
          await cargarAlumnos();
          renderTabla();
          if (alumnoEditandoId === alumnoId) {
            await limpiarFormulario();
          }
        }
      } catch (err) {
        console.error("Error al eliminar alumno", err);
      }
    }
  }
});

document.getElementById('servicio').addEventListener('change', actualizarPaquete);

paqueteClases.addEventListener('change', async () => {
  const packs = await obtenerPacksDisponibles();
  const seleccionado = packs.find(p => p.nombre === paqueteClases.value);
  if (seleccionado) {
    clasesRestantesInput.value = seleccionado.clases;
  } else {
    clasesRestantesInput.value = 0;
  }
});

submitBtn.addEventListener('click', (event) => {
  event.preventDefault();
  form.requestSubmit();
});

window.addEventListener('storage', async (event) => {
  if (event.key === PACKS_STORAGE_KEY) {
    await actualizarListaPaquetes();
  }
  if (event.key === MATERIAS_STORAGE_KEY) {
    await actualizarCamposMaterias();
    renderTabla();
  }
  if (event.key === STORAGE_KEY) {
    await cargarAlumnos();
    renderTabla();
  }
});

[busqueda, filtroMateria, filtroServicio, filtroEstado].forEach((elemento) => {
  elemento.addEventListener('input', renderTabla);
  elemento.addEventListener('change', renderTabla);
});

async function init() {
  await cargarAlumnos();
  await actualizarCamposMaterias();
  await actualizarListaPaquetes();
  renderTabla();
  await limpiarFormulario();
  
  const params = new URLSearchParams(window.location.search);
  if (params.get('open') === 'alumno') {
    modalInstancia.show();
  }
}

init();
