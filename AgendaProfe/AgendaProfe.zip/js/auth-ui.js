(function () {
  const usuario = localStorage.getItem('agendaProfe_usuario');

  if (!usuario) {
    window.location.href = '../index.html';
    return;
  }

  const fab = document.createElement('div');
  fab.id = 'fab-acciones';
  fab.innerHTML = `
    <div class="fab-menu d-none flex-column bg-white rounded-4 p-2 shadow border" id="fabMenu" style="gap: 0.75rem;">
      <button type="button" class="btn btn-outline-primary rounded-pill text-start d-flex align-items-center gap-2 px-3 py-2 mb-2" data-action="alumno">
        <i class="bi bi-person-plus"></i>
        <span>Agregar alumno</span>
      </button>
      <button type="button" class="btn btn-outline-primary rounded-pill text-start d-flex align-items-center gap-2 px-3 py-2 mb-2" data-action="pago">
        <i class="bi bi-cash-stack"></i>
        <span>Agregar pago</span>
      </button>
      <button type="button" class="btn btn-outline-primary rounded-pill text-start d-flex align-items-center gap-2 px-3 py-2" data-action="paquete">
        <i class="bi bi-box-seam"></i>
        <span>Agregar paquete</span>
      </button>
    </div>
    <button type="button" class="fab-toggle btn btn-dark rounded-circle shadow-lg" id="fabToggle" aria-label="Abrir menú de acciones" style="width:3.25rem;height:3.25rem;">
      <i class="bi bi-plus-lg"></i>
    </button>
  `;

  document.body.appendChild(fab);

  const fabToggle = document.getElementById('fabToggle');
  const fabMenu = document.getElementById('fabMenu');

  fabToggle.addEventListener('click', () => {
    fabMenu.classList.toggle('d-none');
    const isOpen = !fabMenu.classList.contains('d-none');
    fabToggle.setAttribute('aria-expanded', String(isOpen));
  });

  document.querySelectorAll('[data-action]').forEach((button) => {
    button.addEventListener('click', () => {
      const action = button.dataset.action;

      const rutas = {
        alumno: 'alumnos.html?open=alumno',
        pago: 'pagos.html',
        paquete: 'packs.html'
      };

      if (rutas[action]) {
        window.location.href = rutas[action];
        return;
      }

      alert(`Acción de ${action} pendiente de implementación.`);
      fabMenu.classList.add('d-none');
      fabToggle.setAttribute('aria-expanded', 'false');
    });
  });

  document.addEventListener('click', (event) => {
    if (!fab.contains(event.target)) {
      fabMenu.classList.add('d-none');
      fabToggle.setAttribute('aria-expanded', 'false');
    }
  });

  // Chequeo de clases pendientes de actualizar en la agenda
  const yaAlertado = sessionStorage.getItem('agendaProfe_alerta_pendiente_actualizada');
  if (!yaAlertado) {
    fetch('/api/agenda')
      .then((response) => {
        if (response.ok) {
          return response.json();
        }
        throw new Error('No se pudieron obtener las clases');
      })
      .then((agenda) => {
        if (Array.isArray(agenda)) {
          const ahora = new Date();
          const pendientes = agenda.some((clase) => {
            if (clase.estado !== 'Programada') return false;
            const fechaHoraClase = new Date(`${clase.fecha}T${clase.hora || '00:00'}`);
            return fechaHoraClase < ahora;
          });

          if (pendientes) {
            alert('Recordá actualizar la información de la agenda');
            sessionStorage.setItem('agendaProfe_alerta_pendiente_actualizada', 'true');
          }
        }
      })
      .catch((error) => {
        console.error('Error al verificar las clases pendientes', error);
      });
  }
})();
