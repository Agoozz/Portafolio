const ALUMNOS_KEY = 'agendaProfe_alumnos';
const AGENDA_KEY = 'agendaProfe_agenda';
const PACKS_KEY = 'agendaProfe_packs';

const clasesHoyValue = document.getElementById('clasesHoyValue');
const pendienteCobrarValue = document.getElementById('pendienteCobrarValue');
const packsActivosValue = document.getElementById('packsActivosValue');
const alumnosActivosValue = document.getElementById('alumnosActivosValue');
const proxClasesBody = document.getElementById('proxClasesBody');
const pagosPendientesList = document.getElementById('pagosPendientesList');

const formateadorMoneda = new Intl.NumberFormat('es-AR', {
  style: 'currency',
  currency: 'ARS',
  maximumFractionDigits: 0
});

async function cargarDatos() {
  const alumnos = await obtenerAlumnos();
  const agenda = await obtenerAgenda();

  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);

  const clasesHoy = agenda.filter((clase) => {
    const fechaClase = new Date(clase.fecha + 'T00:00:00');
    return fechaClase.toDateString() === hoy.toDateString();
  });

  const alumnosActivos = alumnos.filter((alumno) => alumno.estado === 'Activo' || !alumno.estado);
  const alumnosDebedores = alumnos.filter((alumno) => alumno.servicio === 'debe' || Number(alumno.deuda || 0) > 0);
  const pendienteCobrar = alumnosDebedores.reduce((total, alumno) => total + Number(alumno.deuda || 0), 0);

  const alumnosConPack = alumnos.filter((alumno) => alumno.servicio === 'paquete' && (alumno.estado === 'Activo' || !alumno.estado));

  clasesHoyValue.textContent = clasesHoy.length;
  pendienteCobrarValue.textContent = formateadorMoneda.format(pendienteCobrar);
  packsActivosValue.textContent = alumnosConPack.length;
  alumnosActivosValue.textContent = alumnosActivos.length;

  renderProximasClases(agenda);
  renderPagosPendientes(alumnosDebedores);
}

async function obtenerAlumnos() {
  try {
    const response = await fetch('/api/alumnos');
    if (response.ok) {
      return await response.json();
    }
  } catch (error) {
    console.error('No se pudieron leer los alumnos del servidor', error);
  }
  return [];
}

async function obtenerAgenda() {
  try {
    const response = await fetch('/api/agenda');
    if (response.ok) {
      const guardados = await response.json();
      return guardados.sort((a, b) => new Date(`${a.fecha}T${a.hora}`) - new Date(`${b.fecha}T${b.hora}`));
    }
  } catch (error) {
    console.error('No se pudieron leer la agenda del servidor', error);
  }
  return [];
}

function renderProximasClases(agenda) {
  const proximas = agenda
    .filter((clase) => new Date(`${clase.fecha}T${clase.hora}`) >= new Date())
    .slice(0, 5);

  if (!proximas.length) {
    proxClasesBody.innerHTML = `
      <tr>
        <td colspan="4" class="text-center text-muted py-4">No hay clases próximas registradas.</td>
      </tr>
    `;
    return;
  }

  proxClasesBody.innerHTML = proximas.map((clase) => {
    const hora = clase.hora || '00:00';
    const fecha = new Date(`${clase.fecha}T${hora}`).toLocaleDateString('es-AR', {
      day: '2-digit',
      month: '2-digit'
    });

    const estadoClase = clase.estado === 'Programada' ? 'bg-primary-subtle text-primary' : clase.estado === 'Completada' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger';

    return `
      <tr>
        <td>
          <span class="badge bg-primary rounded-pill px-3 py-2">${hora}</span>
        </td>
        <td class="fw-semibold">${clase.alumno}</td>
        <td>${clase.materia}</td>
        <td>
          <span class="badge ${estadoClase} rounded-pill px-3 py-2">${clase.estado}</span>
        </td>
      </tr>
    `;
  }).join('');
}

function renderPagosPendientes(alumnosDebedores) {
  if (!alumnosDebedores.length) {
    pagosPendientesList.innerHTML = `
      <div class="list-group-item px-0 text-muted">No hay deudas pendientes registradas.</div>
    `;
    return;
  }

  pagosPendientesList.innerHTML = alumnosDebedores.map((alumno) => `
    <a href="pagos.html?alumnoId=${alumno.id}" class="list-group-item list-group-item-action px-0 d-flex justify-content-between align-items-center border-0 bg-transparent">
      <span>${alumno.nombre} ${alumno.apellido} <i class="bi bi-arrow-right-short text-muted"></i></span>
      <strong class="text-danger">${formateadorMoneda.format(Number(alumno.deuda || 0))}</strong>
    </a>
  `).join('');
}

window.addEventListener('storage', (event) => {
  if (['agendaProfe_alumnos', 'agendaProfe_agenda', 'agendaProfe_packs'].includes(event.key)) {
    cargarDatos();
  }
});

cargarDatos();
