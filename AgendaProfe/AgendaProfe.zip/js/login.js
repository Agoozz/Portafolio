const loginForm = document.getElementById("loginForm");
const usuarioInput = document.getElementById("usuario");
const passwordInput = document.getElementById("password");
const loginError = document.getElementById("loginError");



loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const usuario = usuarioInput.value.trim();
  const password = passwordInput.value.trim();

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ usuario, password })
    });

    if (response.ok) {
      const data = await response.json();
      localStorage.setItem("agendaProfe_usuario", data.usuario);
      window.location.href = "pantallas/inicio.html";
    } else {
      loginError.textContent = "Usuario o contraseña incorrectos.";
      loginError.classList.remove("d-none");
    }
  } catch (error) {
    console.error("Error al iniciar sesión:", error);
    loginError.textContent = "Error al conectar con el servidor.";
    loginError.classList.remove("d-none");
  }
});