const form = document.getElementById('packForm');
const tablaBody = document.getElementById('packTableBody');
const contador = document.getElementById('contadorPacks');
const materiasTableBody = document.getElementById('materiasTableBody');
const contadorMaterias = document.getElementById('contadorMaterias');
const modalPack = document.getElementById('modalPack');
const modalInstancia = bootstrap.Modal.getOrCreateInstance(modalPack);
const submitBtn = document.getElementById('guardarPackBtn');
const nuevaMateriaInput = document.getElementById('nuevaMateria');
const btnAgregarMateria = document.getElementById('agregarMateriaBtn');

let packs = [];
let materias = [];
let alumnos = [];
let clases = [];
let packEditandoId = null;

function ordenarPacks(lista) {
  return [...lista].sort((a, b) => Number(a.clases) - Number(b.clases) || String(a.nombre).localeCompare(String(b.nombre)));
}

async function cargarDatos() {
  try {
    const [packsRes, materiasRes, alumnosRes, agendaRes] = await Promise.all([
      fetch('/api/packs'),
      fetch('/api/materias'),
      fetch('/api/alumnos'),
      fetch('/api/agenda')
    ]);

    if (packsRes.ok) {
      const data = await packsRes.json();
      packs = ordenarPacks(data);
    }
    if (materiasRes.ok) {
      materias = await materiasRes.json();
    }
    if (alumnosRes.ok) {
      alumnos = await alumnosRes.json();
    }
    if (agendaRes.ok) {
      clases = await agendaRes.json();
    }
  } catch (error) {
    console.error('Error al cargar datos del servidor', error);
  }
}

function renderTabla() {
  contador.textContent = `${packs.length} pack${packs.length === 1 ? '' : 's'}`;

  if (!packs.length) {
    tablaBody.innerHTML = `
      <tr>
        <td colspan="5" class="text-center text-muted py-4">No hay packs cargados todavía. Agregá el primero.</td>
      </tr>
    `;
    return;
  }

  tablaBody.innerHTML = packs.map((pack) => `
    <tr>
      <td>
        <div class="fw-semibold">${pack.nombre}</div>
        <div class="small text-muted">Editable desde la tabla o con el modal</div>
      </td>
      <td>
        <input type="number" min="0" step="1" class="form-control form-control-sm rounded-3 precio-pack-input" data-id="${pack.id}" value="${pack.precio}" aria-label="Precio de ${pack.nombre}">
      </td>
      <td>
        <div class="d-flex align-items-center gap-2">
          <button type="button" class="btn btn-sm btn-outline-secondary rounded-circle" data-action="decrementar-clases" data-id="${pack.id}" aria-label="Restar clase">−</button>
          <span class="badge bg-primary-subtle text-primary px-3 py-2">${pack.clases} clases</span>
          <button type="button" class="btn btn-sm btn-outline-secondary rounded-circle" data-action="incrementar-clases" data-id="${pack.id}" aria-label="Sumar clase">+</button>
        </div>
      </td>
      <td>
        <span class="badge ${pack.activo ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'}">
          ${pack.activo ? 'Activo' : 'Inactivo'}
        </span>
      </td>
      <td>
        <div class="d-flex gap-2">
          <button type="button" class="btn btn-sm btn-outline-primary" data-action="editar" data-id="${pack.id}">Editar</button>
          <button type="button" class="btn btn-sm btn-outline-danger" data-action="eliminar" data-id="${pack.id}">Eliminar</button>
        </div>
      </td>
    </tr>
  `).join('');
}

function renderMaterias() {
  contadorMaterias.textContent = `${materias.length} materia${materias.length === 1 ? '' : 's'}`;

  if (!materias.length) {
    materiasTableBody.innerHTML = `
      <tr>
        <td colspan="2" class="text-center text-muted py-4">No hay materias cargadas. Agregá la primera.</td>
      </tr>
    `;
    return;
  }

  materiasTableBody.innerHTML = materias.map((materia) => `
    <tr>
      <td class="fw-semibold">${materia}</td>
      <td>
        <button type="button" class="btn btn-sm btn-outline-danger" data-action="eliminar-materia" data-materia="${encodeURIComponent(materia)}">Eliminar</button>
      </td>
    </tr>
  `).join('');
}

function limpiarFormulario() {
  form.reset();
  document.getElementById('packId').value = '';
  document.getElementById('precioPack').value = 0;
  document.getElementById('clasesPack').value = 4;
  packEditandoId = null;
  if (submitBtn) {
    submitBtn.textContent = 'Guardar pack';
  }
}

function cargarPackEnFormulario(pack) {
  document.getElementById('packId').value = pack.id;
  document.getElementById('nombrePack').value = pack.nombre;
  document.getElementById('precioPack').value = pack.precio;
  document.getElementById('clasesPack').value = pack.clases;
  packEditandoId = pack.id;
  if (submitBtn) {
    submitBtn.textContent = 'Actualizar pack';
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  try {
    const nombre = document.getElementById('nombrePack').value.trim();
    const precio = Number(document.getElementById('precioPack').value || 0);
    const clasesValue = Number(document.getElementById('clasesPack').value || 0);

    if (!nombre) {
      alert('Ingresá un nombre para el pack');
      return;
    }

    const pack = {
      id: packEditandoId || Date.now(),
      nombre,
      precio,
      clases: Math.max(1, clasesValue),
      activo: true
    };

    let response;
    if (packEditandoId) {
      response = await fetch(`/api/packs/${packEditandoId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pack)
      });
    } else {
      response = await fetch('/api/packs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pack)
      });
    }

    if (response.ok) {
      window.dispatchEvent(new StorageEvent('storage', {
        key: 'agendaProfe_packs'
      }));
      await cargarDatos();
      renderTabla();
      limpiarFormulario();
      modalInstancia.hide();
    }
  } catch (error) {
    console.error('Error al guardar el pack', error);
  }
});

const cancelarEdicionBtn = document.getElementById('cancelarEdicion');
cancelarEdicionBtn.addEventListener('click', () => {
  limpiarFormulario();
  modalInstancia.hide();
});

modalPack.addEventListener('hidden.bs.modal', () => {
  limpiarFormulario();
});

tablaBody.addEventListener('click', async (event) => {
  const boton = event.target.closest('[data-action]');
  if (!boton) return;

  const packId = Number(boton.dataset.id);
  const pack = packs.find((item) => item.id === packId);
  if (!pack) return;

  if (boton.dataset.action === 'editar') {
    cargarPackEnFormulario(pack);
    modalInstancia.show();
  }

  if (boton.dataset.action === 'eliminar') {
    const enUsoAlumnos = alumnos.filter(a => a.servicio === 'paquete' && a.paquete === pack.nombre);
    
    if (enUsoAlumnos.length) {
      const mensaje = `El pack "${pack.nombre}" está asignado a ${enUsoAlumnos.length} alumno(s).\n\n¿Estás seguro de que querés eliminarlo?`;
      if (!confirm(mensaje)) return;
    }

    try {
      const response = await fetch(`/api/packs/${packId}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        window.dispatchEvent(new StorageEvent('storage', {
          key: 'agendaProfe_packs'
        }));
        await cargarDatos();
        renderTabla();
        if (packEditandoId === packId) {
          limpiarFormulario();
        }
      }
    } catch (error) {
      console.error('Error al eliminar el pack', error);
    }
  }

  if (boton.dataset.action === 'incrementar-clases') {
    pack.clases += 1;
    try {
      const response = await fetch(`/api/packs/${pack.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pack)
      });
      if (response.ok) {
        window.dispatchEvent(new StorageEvent('storage', {
          key: 'agendaProfe_packs'
        }));
        renderTabla();
      }
    } catch (error) {
      console.error('Error al incrementar clases', error);
    }
  }

  if (boton.dataset.action === 'decrementar-clases') {
    pack.clases = Math.max(1, pack.clases - 1);
    try {
      const response = await fetch(`/api/packs/${pack.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pack)
      });
      if (response.ok) {
        window.dispatchEvent(new StorageEvent('storage', {
          key: 'agendaProfe_packs'
        }));
        renderTabla();
      }
    } catch (error) {
      console.error('Error al decrementar clases', error);
    }
  }
});

tablaBody.addEventListener('change', async (event) => {
  if (!event.target.classList.contains('precio-pack-input')) return;

  const packId = Number(event.target.dataset.id);
  const pack = packs.find((item) => item.id === packId);
  if (!pack) return;

  pack.precio = Number(event.target.value || 0);
  try {
    const response = await fetch(`/api/packs/${pack.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(pack)
    });
    if (response.ok) {
      window.dispatchEvent(new StorageEvent('storage', {
        key: 'agendaProfe_packs'
      }));
      renderTabla();
    }
  } catch (error) {
    console.error('Error al actualizar precio del pack', error);
  }
});

document.getElementById('btnNuevoPack').addEventListener('click', () => {
  limpiarFormulario();
  modalInstancia.show();
});

btnAgregarMateria.addEventListener('click', async () => {
  const nuevaMateria = nuevaMateriaInput.value.trim();

  if (!nuevaMateria) {
    alert('Ingresá una materia para agregarla');
    return;
  }

  if (materias.some((materia) => materia.toLowerCase() === nuevaMateria.toLowerCase())) {
    alert('Esa materia ya existe');
    return;
  }

  try {
    const response = await fetch('/api/materias', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre: nuevaMateria })
    });
    if (response.ok) {
      window.dispatchEvent(new StorageEvent('storage', {
        key: 'agendaProfe_materias'
      }));
      await cargarDatos();
      renderMaterias();
      nuevaMateriaInput.value = '';
    }
  } catch (error) {
    console.error('Error al agregar materia', error);
  }
});

nuevaMateriaInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    btnAgregarMateria.click();
  }
});

materiasTableBody.addEventListener('click', async (event) => {
  const boton = event.target.closest('[data-action="eliminar-materia"]');
  if (!boton) return;

  const materia = decodeURIComponent(boton.dataset.materia);

  const enUsoAlumnos = alumnos.filter(a => a.materias && a.materias.includes(materia));
  const enUsoAgenda = clases.filter(c => c.materia === materia);

  if (enUsoAlumnos.length || enUsoAgenda.length) {
    let mensaje = `La materia "${materia}" está siendo usada en:\n`;
    if (enUsoAlumnos.length) {
      mensaje += `- ${enUsoAlumnos.length} alumno(s)\n`;
    }
    if (enUsoAgenda.length) {
      mensaje += `- ${enUsoAgenda.length} clase(s) programada(s)\n`;
    }
    mensaje += `\n¿Estás seguro de que querés eliminarla?`;
    
    if (!confirm(mensaje)) {
      return;
    }
  }

  try {
    const response = await fetch(`/api/materias/${encodeURIComponent(materia)}`, {
      method: 'DELETE'
    });
    if (response.ok) {
      window.dispatchEvent(new StorageEvent('storage', {
        key: 'agendaProfe_materias'
      }));
      await cargarDatos();
      renderMaterias();
    }
  } catch (error) {
    console.error('Error al eliminar materia', error);
  }
});

window.addEventListener('storage', async (event) => {
  if (event.key === 'agendaProfe_materias' || event.key === 'agendaProfe_packs' || event.key === 'agendaProfe_alumnos' || event.key === 'agendaProfe_agenda') {
    await cargarDatos();
    renderMaterias();
    renderTabla();
  }
});

async function init() {
  await cargarDatos();
  renderTabla();
  renderMaterias();
  limpiarFormulario();
}

init();

