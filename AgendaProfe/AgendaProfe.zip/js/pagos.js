const form = document.getElementById('pagoForm');
const alumnoSelect = document.getElementById('alumnoPago');
const tablaBody = document.getElementById('pagosTableBody');
const contador = document.getElementById('contadorPagos');
const estadoVacio = document.getElementById('estadoVacio');
const btnRegistrarAlumno = document.getElementById('btnRegistrarAlumno');

let pagos = [];
let alumnos = [];

async function cargarAlumnos() {
  try {
    const response = await fetch('/api/alumnos');
    if (response.ok) {
      alumnos = await response.json();
    }
  } catch (error) {
    console.error('No se pudieron leer los alumnos del servidor', error);
  }
}

async function cargarPagos() {
  try {
    const response = await fetch('/api/pagos');
    if (response.ok) {
      const guardados = await response.json();
      pagos = guardados.sort((a, b) => new Date(`${b.fecha}T${b.hora}`) - new Date(`${a.fecha}T${a.hora}`));
    }
  } catch (error) {
    console.error('No se pudieron leer los pagos del servidor', error);
  }
}

function popularAlumnosSelect() {
  const seleccionActual = alumnoSelect.value;

  alumnoSelect.innerHTML = '<option value="">Seleccioná un alumno</option>' + alumnos.map((alumno) => `
    <option value="${alumno.id}" ${String(alumno.id) === String(seleccionActual) ? 'selected' : ''}>
      ${alumno.nombre} ${alumno.apellido} (${alumno.servicio === 'paquete' ? 'Paquete' : 'Clase'})
    </option>
  `).join('');

  if (alumnos.length === 0) {
    alumnoSelect.innerHTML = '<option value="">No hay alumnos registrados</option>';
    alumnoSelect.disabled = true;
    estadoVacio.classList.remove('d-none');
  } else {
    alumnoSelect.disabled = false;
    estadoVacio.classList.add('d-none');
  }
}

function renderTabla() {
  contador.textContent = `${pagos.length} pago${pagos.length === 1 ? '' : 's'}`;

  if (!pagos.length) {
    tablaBody.innerHTML = `
      <tr>
        <td colspan="5" class="text-center text-muted py-4">Todavía no hay pagos registrados.</td>
      </tr>
    `;
    return;
  }

  tablaBody.innerHTML = pagos.map((pago) => `
    <tr>
      <td>${pago.alumnoNombre}</td>
      <td>$${Number(pago.monto).toLocaleString('es-AR')}</td>
      <td>${new Date(`${pago.fecha}T${pago.hora || '00:00'}`).toLocaleDateString('es-AR')}</td>
      <td>${pago.metodo}</td>
      <td>${pago.observaciones || 'Sin observaciones'}</td>
    </tr>
  `).join('');
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const alumnoId = alumnoSelect.value;
  const alumno = alumnos.find((item) => String(item.id) === String(alumnoId));

  if (!alumno) {
    alert('Seleccioná un alumno válido para registrar el pago');
    return;
  }

  const monto = Number(document.getElementById('montoPago').value || 0);
  if (!monto || monto <= 0) {
    alert('Ingresá un monto mayor a cero');
    return;
  }

  const pago = {
    id: Date.now(),
    alumnoId: alumno.id,
    alumnoNombre: `${alumno.nombre} ${alumno.apellido}`,
    monto,
    fecha: document.getElementById('fechaPago').value || new Date().toISOString().split('T')[0],
    hora: document.getElementById('horaPago').value || new Date().toTimeString().slice(0, 5),
    metodo: document.getElementById('metodoPago').value,
    observaciones: document.getElementById('observacionesPago').value.trim()
  };

  try {
    const response = await fetch('/api/pagos', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(pago)
    });

    if (response.ok) {
      window.dispatchEvent(new StorageEvent('storage', {
        key: 'agendaProfe_pagos'
      }));
      window.dispatchEvent(new StorageEvent('storage', {
        key: 'agendaProfe_alumnos'
      }));

      await cargarPagos();
      await cargarAlumnos();
      renderTabla();
      form.reset();
      document.getElementById('fechaPago').value = new Date().toISOString().split('T')[0];
      document.getElementById('horaPago').value = new Date().toTimeString().slice(0, 5);
      popularAlumnosSelect();
    }
  } catch (error) {
    console.error('Error al registrar el pago', error);
  }
});

btnRegistrarAlumno.addEventListener('click', () => {
  window.location.href = 'alumnos.html?open=alumno';
});

window.addEventListener('storage', async (event) => {
  if (event.key === 'agendaProfe_alumnos' || event.key === 'agendaProfe_pagos') {
    await cargarAlumnos();
    await cargarPagos();
    popularAlumnosSelect();
    renderTabla();
  }
});

async function init() {
  const params = new URLSearchParams(window.location.search);
  const alumnoIdParam = params.get('alumnoId');

  await cargarAlumnos();
  await cargarPagos();
  
  if (alumnoIdParam) {
    alumnoSelect.value = alumnoIdParam;
  }

  popularAlumnosSelect();
  renderTabla();

  const fechaHoy = new Date().toISOString().split('T')[0];
  const horaActual = new Date().toTimeString().slice(0, 5);
  document.getElementById('fechaPago').value = fechaHoy;
  document.getElementById('horaPago').value = horaActual;
}

init();

