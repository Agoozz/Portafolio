const monthInput = document.getElementById('mesReporte');
const reporteMonthLabel = document.getElementById('reporteMonthLabel');
const alumnosAtendidosValue = document.getElementById('alumnosAtendidosValue');
const clasesMesValue = document.getElementById('clasesMesValue');
const pagosMesValue = document.getElementById('pagosMesValue');
const gananciaMesValue = document.getElementById('gananciaMesValue');
const reporteBody = document.getElementById('reporteBody');

const formateadorMoneda = new Intl.NumberFormat('es-AR', {
  style: 'currency',
  currency: 'ARS',
  maximumFractionDigits: 0
});

let clases = [];
let pagos = [];

async function cargarDatos() {
  try {
    const [agendaRes, pagosRes] = await Promise.all([
      fetch('/api/agenda'),
      fetch('/api/pagos')
    ]);
    
    if (agendaRes.ok) {
      clases = await agendaRes.json();
    }
    if (pagosRes.ok) {
      pagos = await pagosRes.json();
    }
  } catch (error) {
    console.error('Error al cargar datos para reportes', error);
  }
}

function renderReporte() {
  const mesSeleccionado = monthInput.value || obtenerMesActual();
  monthInput.value = mesSeleccionado;

  const clasesMes = clases.filter((clase) =>
    clase.fecha?.startsWith(mesSeleccionado) && clase.estado !== 'Cancelada'
  );

  const pagosMes = pagos.filter((pago) =>
    pago.fecha?.startsWith(mesSeleccionado)
  );

  const totalGanado = pagosMes.reduce((total, pago) => total + Number(pago.monto || 0), 0);
  const alumnosAtendidos = new Set(clasesMes.map((clase) => clase.alumno)).size;

  const clasesPorAlumno = new Map();
  clasesMes.forEach((clase) => {
    clasesPorAlumno.set(clase.alumno, (clasesPorAlumno.get(clase.alumno) || 0) + 1);
  });

  const pagosPorAlumno = new Map();
  pagosMes.forEach((pago) => {
    pagosPorAlumno.set(pago.alumnoNombre, (pagosPorAlumno.get(pago.alumnoNombre) || 0) + Number(pago.monto || 0));
  });

  const pagosCountPorAlumno = new Map();
  pagosMes.forEach((pago) => {
    pagosCountPorAlumno.set(pago.alumnoNombre, (pagosCountPorAlumno.get(pago.alumnoNombre) || 0) + 1);
  });

  const alumnosReporte = Array.from(new Set([
    ...clasesMes.map((clase) => clase.alumno),
    ...pagosMes.map((pago) => pago.alumnoNombre)
  ]));

  alumnosReporte.sort((a, b) => {
    const clasesA = clasesPorAlumno.get(a) || 0;
    const clasesB = clasesPorAlumno.get(b) || 0;
    const ingresoA = pagosPorAlumno.get(a) || 0;
    const ingresoB = pagosPorAlumno.get(b) || 0;

    return (clasesB - clasesA) || (ingresoB - ingresoA) || a.localeCompare(b);
  });

  alumnosAtendidosValue.textContent = alumnosAtendidos;
  clasesMesValue.textContent = clasesMes.length;
  pagosMesValue.textContent = pagosMes.length;
  gananciaMesValue.textContent = formateadorMoneda.format(totalGanado);

  const fechaLabel = new Date(`${mesSeleccionado}-01T00:00:00`);
  reporteMonthLabel.textContent = fechaLabel.toLocaleDateString('es-AR', {
    month: 'long',
    year: 'numeric'
  }).replace(/^\w/, (letra) => letra.toUpperCase());

  if (!alumnosReporte.length) {
    reporteBody.innerHTML = `
      <tr>
        <td colspan="4" class="text-center text-muted py-4">No hay clases ni pagos registrados para este mes.</td>
      </tr>
    `;
    return;
  }

  reporteBody.innerHTML = alumnosReporte.map((alumno) => `
    <tr>
      <td class="fw-semibold">${alumno}</td>
      <td><span class="badge bg-primary-subtle text-primary rounded-pill px-3 py-2">${clasesPorAlumno.get(alumno) || 0}</span></td>
      <td><span class="badge bg-success-subtle text-success rounded-pill px-3 py-2">${pagosCountPorAlumno.get(alumno) || 0}</span></td>
      <td class="fw-semibold text-primary">${formateadorMoneda.format(pagosPorAlumno.get(alumno) || 0)}</td>
    </tr>
  `).join('');
}

function obtenerMesActual() {
  const hoy = new Date();
  return `${hoy.getFullYear()}-${String(hoy.getMonth() + 1).padStart(2, '0')}`;
}

monthInput.addEventListener('change', renderReporte);
window.addEventListener('storage', async (event) => {
  if (event.key === 'agendaProfe_agenda' || event.key === 'agendaProfe_pagos') {
    await cargarDatos();
    renderReporte();
  }
});

async function init() {
  await cargarDatos();
  renderReporte();
}

init();

