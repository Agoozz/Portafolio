import os
import sqlite3
import json
from flask import Flask, request, jsonify, send_from_directory, send_file

app = Flask(__name__)

# Check if PostgreSQL should be used
DATABASE_URL = os.environ.get('DATABASE_URL')
IS_POSTGRES = DATABASE_URL is not None
if IS_POSTGRES:
    import psycopg2
    import psycopg2.extras
    if DATABASE_URL.startswith("postgres://"):
        DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

# Directorio base
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'agenda.db')

class CursorWrapper:
    def __init__(self, cur, is_pg=False):
        self.cur = cur
        self.is_pg = is_pg

    def execute(self, query, params=()):
        if self.is_pg:
            query = query.replace('?', '%s')
            query = query.replace('INTEGER PRIMARY KEY AUTOINCREMENT', 'SERIAL PRIMARY KEY')
            query = query.replace('MAX(0, deuda - %s)', 'GREATEST(0, deuda - %s)')
            # Handle max(0, debt - X) when it is parameter-bound
            query = query.replace('MAX(0, deuda - %s)', 'GREATEST(0, deuda - %s)')
        self.cur.execute(query, params)
        return self

    def fetchone(self):
        return self.cur.fetchone()

    def fetchall(self):
        return self.cur.fetchall()

    def __iter__(self):
        return iter(self.cur)

class DBWrapper:
    def __init__(self, conn, is_pg=False):
        self.conn = conn
        self.is_pg = is_pg

    def execute(self, query, params=()):
        if self.is_pg:
            query = query.replace('?', '%s')
            query = query.replace('MAX(0, deuda - %s)', 'GREATEST(0, deuda - %s)')
        cur = self.conn.cursor()
        cur.execute(query, params)
        return CursorWrapper(cur, self.is_pg)

    def commit(self):
        self.conn.commit()

    def close(self):
        self.conn.close()

    def cursor(self):
        cur = self.conn.cursor()
        return CursorWrapper(cur, self.is_pg)

def get_db_connection():
    if IS_POSTGRES:
        conn = psycopg2.connect(DATABASE_URL, cursor_factory=psycopg2.extras.DictCursor)
        return DBWrapper(conn, is_pg=True)
    else:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return DBWrapper(conn, is_pg=False)


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 1. Tabla usuarios
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT UNIQUE,
            password TEXT
        )
    ''')
    
    # 2. Tabla alumnos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS alumnos (
            id INTEGER PRIMARY KEY,
            nombre TEXT,
            apellido TEXT,
            telefono TEXT,
            email TEXT,
            servicio TEXT,
            paquete TEXT,
            clasesRestantes INTEGER,
            deuda REAL,
            materias TEXT,
            estado TEXT,
            observaciones TEXT,
            fechaAlta TEXT
        )
    ''')
    
    # 3. Tabla clases
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clases (
            id INTEGER PRIMARY KEY,
            alumno TEXT,
            materia TEXT,
            fecha TEXT,
            hora TEXT,
            estado TEXT,
            observaciones TEXT
        )
    ''')
    
    # 4. Tabla packs
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS packs (
            id INTEGER PRIMARY KEY,
            nombre TEXT,
            precio REAL,
            clases INTEGER,
            activo INTEGER
        )
    ''')
    
    # 5. Tabla materias
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS materias (
            nombre TEXT PRIMARY KEY
        )
    ''')
    
    # 6. Tabla pagos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pagos (
            id INTEGER PRIMARY KEY,
            alumnoId INTEGER,
            alumnoNombre TEXT,
            monto REAL,
            fecha TEXT,
            hora TEXT,
            metodo TEXT,
            observaciones TEXT
        )
    ''')
    
    # Insertar usuario demo
    cursor.execute("SELECT COUNT(*) FROM usuarios")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO usuarios (usuario, password) VALUES (?, ?)", ('glo', '24284992'))

        
    # Insertar packs demo
    cursor.execute("SELECT COUNT(*) FROM packs")
    if cursor.fetchone()[0] == 0:
        demo_packs = [
            (1, 'Pack básico', 3200, 4, 1),
            (2, 'Pack intermedio', 6000, 8, 1),
            (3, 'Pack completo', 9000, 12, 1)
        ]
        cursor.executemany("INSERT INTO packs (id, nombre, precio, clases, activo) VALUES (?, ?, ?, ?, ?)", demo_packs)
        
    # Insertar materias demo
    cursor.execute("SELECT COUNT(*) FROM materias")
    if cursor.fetchone()[0] == 0:
        demo_materias = [
            ('Análisis matemático 1',),
            ('Análisis matemático 2',),
            ('Álgebra y geometría analítica',),
            ('Primario',),
            ('Secundario',)
        ]
        cursor.executemany("INSERT INTO materias (nombre) VALUES (?)", demo_materias)
        
    conn.commit()
    conn.close()

def adjust_student_classes(conn, student_name, delta):
    rows = conn.execute("SELECT id, nombre, apellido, clasesRestantes, servicio FROM alumnos").fetchall()
    for r in rows:
        fullname = f"{r['nombre']} {r['apellido']}".strip()
        if fullname.lower() == student_name.strip().lower() and r['servicio'] == 'paquete':
            new_balance = max(0, (r['clasesRestantes'] or 0) + delta)
            conn.execute("UPDATE alumnos SET clasesRestantes = ? WHERE id = ?", (new_balance, r['id']))
            break

# Rutas estáticas de la aplicación
@app.route('/')
def index():
    return send_file(os.path.join(BASE_DIR, 'index.html'))

@app.route('/style.css')
def style():
    return send_file(os.path.join(BASE_DIR, 'style.css'))

@app.route('/pantallas/<path:filename>')
def pantallas(filename):
    return send_from_directory(os.path.join(BASE_DIR, 'pantallas'), filename)

@app.route('/js/<path:filename>')
def js(filename):
    return send_from_directory(os.path.join(BASE_DIR, 'js'), filename)

# API REST
@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    usuario = data.get('usuario')
    password = data.get('password')
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM usuarios WHERE usuario = ? AND password = ?', (usuario, password)).fetchone()
    conn.close()
    
    if user:
        return jsonify({'success': True, 'usuario': user['usuario']})
    else:
        return jsonify({'success': False, 'message': 'Usuario o contraseña incorrectos'}), 401

# CRUD Alumnos
@app.route('/api/alumnos', methods=['GET'])
def get_alumnos():
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM alumnos').fetchall()
    conn.close()
    
    alumnos = []
    for r in rows:
        alumno = dict(r)
        try:
            alumno['materias'] = json.loads(r['materias']) if r['materias'] else []
        except:
            alumno['materias'] = []
        alumnos.append(alumno)
    return jsonify(alumnos)

@app.route('/api/alumnos', methods=['POST'])
def add_alumno():
    data = request.json
    conn = get_db_connection()
    materias = json.dumps(data.get('materias', []))
    
    conn.execute('''
        INSERT INTO alumnos (id, nombre, apellido, telefono, email, servicio, paquete, clasesRestantes, deuda, materias, estado, observaciones, fechaAlta)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        data.get('id'),
        data.get('nombre'),
        data.get('apellido'),
        data.get('telefono'),
        data.get('email'),
        data.get('servicio'),
        data.get('paquete'),
        data.get('clasesRestantes', 0),
        data.get('deuda', 0),
        materias,
        data.get('estado'),
        data.get('observaciones'),
        data.get('fechaAlta')
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True}), 201

@app.route('/api/alumnos/<int:id>', methods=['PUT'])
def update_alumno(id):
    data = request.json
    conn = get_db_connection()
    materias = json.dumps(data.get('materias', []))
    
    conn.execute('''
        UPDATE alumnos
        SET nombre=?, apellido=?, telefono=?, email=?, servicio=?, paquete=?, clasesRestantes=?, deuda=?, materias=?, estado=?, observaciones=?
        WHERE id=?
    ''', (
        data.get('nombre'),
        data.get('apellido'),
        data.get('telefono'),
        data.get('email'),
        data.get('servicio'),
        data.get('paquete'),
        data.get('clasesRestantes', 0),
        data.get('deuda', 0),
        materias,
        data.get('estado'),
        data.get('observaciones'),
        id
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/alumnos/<int:id>', methods=['DELETE'])
def delete_alumno(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM alumnos WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

# CRUD Agenda/Clases
@app.route('/api/agenda', methods=['GET'])
def get_classes():
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM clases').fetchall()
    conn.close()
    clases = [dict(r) for r in rows]
    return jsonify(clases)

@app.route('/api/agenda', methods=['POST'])
def add_class():
    data = request.json
    conn = get_db_connection()
    estado = data.get('estado')
    alumno = data.get('alumno')
    
    if estado == 'Completada':
        adjust_student_classes(conn, alumno, -1)
        
    conn.execute('''
        INSERT INTO clases (id, alumno, materia, fecha, hora, estado, observaciones)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        data.get('id'),
        alumno,
        data.get('materia'),
        data.get('fecha'),
        data.get('hora'),
        estado,
        data.get('observaciones')
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True}), 201

@app.route('/api/agenda/<int:id>', methods=['PUT'])
def update_class(id):
    data = request.json
    conn = get_db_connection()
    estado = data.get('estado')
    alumno = data.get('alumno')
    
    prev = conn.execute('SELECT estado, alumno FROM clases WHERE id = ?', (id,)).fetchone()
    if prev:
        prev_estado = prev['estado']
        if prev_estado != 'Completada' and estado == 'Completada':
            adjust_student_classes(conn, alumno, -1)
        elif prev_estado == 'Completada' and estado != 'Completada':
            adjust_student_classes(conn, alumno, 1)
            
    conn.execute('''
        UPDATE clases
        SET alumno=?, materia=?, fecha=?, hora=?, estado=?, observaciones=?
        WHERE id=?
    ''', (
        alumno,
        data.get('materia'),
        data.get('fecha'),
        data.get('hora'),
        estado,
        data.get('observaciones'),
        id
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/agenda/<int:id>', methods=['DELETE'])
def delete_class(id):
    conn = get_db_connection()
    prev = conn.execute('SELECT estado, alumno FROM clases WHERE id = ?', (id,)).fetchone()
    if prev and prev['estado'] == 'Completada':
        adjust_student_classes(conn, prev['alumno'], 1)
        
    conn.execute('DELETE FROM clases WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

# CRUD Packs
@app.route('/api/packs', methods=['GET'])
def get_packs():
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM packs').fetchall()
    conn.close()
    packs = [dict(r) for r in rows]
    for p in packs:
        p['activo'] = bool(p['activo'])
    return jsonify(packs)

@app.route('/api/packs', methods=['POST'])
def add_pack():
    data = request.json
    conn = get_db_connection()
    conn.execute('''
        INSERT INTO packs (id, nombre, precio, clases, activo)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        data.get('id'),
        data.get('nombre'),
        data.get('precio'),
        data.get('clases'),
        1 if data.get('activo', True) else 0
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True}), 201

@app.route('/api/packs/<int:id>', methods=['PUT'])
def update_pack(id):
    data = request.json
    conn = get_db_connection()
    conn.execute('''
        UPDATE packs
        SET nombre=?, precio=?, clases=?, activo=?
        WHERE id=?
    ''', (
        data.get('nombre'),
        data.get('precio'),
        data.get('clases'),
        1 if data.get('activo', True) else 0,
        id
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/packs/<int:id>', methods=['DELETE'])
def delete_pack(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM packs WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

# CRUD Materias
@app.route('/api/materias', methods=['GET'])
def get_materias():
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM materias').fetchall()
    conn.close()
    materias = [r['nombre'] for r in rows]
    return jsonify(materias)

@app.route('/api/materias', methods=['POST'])
def add_materia():
    data = request.json
    conn = get_db_connection()
    conn.execute('INSERT INTO materias (nombre) VALUES (?)', (data.get('nombre'),))
    conn.commit()
    conn.close()
    return jsonify({'success': True}), 201

@app.route('/api/materias/<string:nombre>', methods=['DELETE'])
def delete_materia(nombre):
    conn = get_db_connection()
    conn.execute('DELETE FROM materias WHERE nombre = ?', (nombre,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

# CRUD Pagos
@app.route('/api/pagos', methods=['GET'])
def get_pagos():
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM pagos ORDER BY id DESC').fetchall()
    conn.close()
    pagos = [dict(r) for r in rows]
    return jsonify(pagos)

@app.route('/api/pagos', methods=['POST'])
def add_pago():
    data = request.json
    conn = get_db_connection()
    alumno_id = data.get('alumnoId')
    monto = float(data.get('monto', 0))
    
    # Restar de la deuda del alumno
    conn.execute('UPDATE alumnos SET deuda = MAX(0, deuda - ?) WHERE id = ?', (monto, alumno_id))
    
    conn.execute('''
        INSERT INTO pagos (id, alumnoId, alumnoNombre, monto, fecha, hora, metodo, observaciones)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        data.get('id'),
        alumno_id,
        data.get('alumnoNombre'),
        monto,
        data.get('fecha'),
        data.get('hora'),
        data.get('metodo'),
        data.get('observaciones')
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True}), 201

if __name__ == '__main__':
    init_db()
    print("Iniciando servidor Flask en http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)

